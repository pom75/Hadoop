package ihm;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MainPanel extends JPanel {

	JLabel l1,l2;
	JTextField f1,f2;
	
	public MainPanel() {
		init();
	
	}
	
	private void init(){
		l1  = new JLabel("Dimention");
		f1  =  new JL
		
	}
}
