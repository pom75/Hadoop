import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class Julia {
	static public double real = -0.8;
	static public double imag = -0.4;
	public Complex c = new Complex(real, imag); 
	static double xmin   = -2.0;
	static double ymin   = -2.0;
	static double width  =  4.0;
	static double height =  4.0;
	static int dim = 1000;
	static Picture pic = new Picture(dim, dim);
	static boolean test = true;
	public static List<Integer> colors;


	public static void main(String[] args) throws Exception {


		colors = getUniqueColors(256);

		Configuration conf = new Configuration();
		conf.setBoolean("mapreduce.map.speculative", false);
		conf.setBoolean("mapreduce.reduce.speculative", false);
		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		if (otherArgs.length != 2) {
			System.err.println("Usage: wordcount <in> <out> ");
			System.exit(2);
		}
		Job job = Job.getInstance(conf, "word count");
		job.setJarByClass(Julia.class);
		job.setMapperClass(TokenizerMapper.class);
		job.setReducerClass(IntSumReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		job.setNumReduceTasks(1);//Il est bien sur possible de changer cette valeur (1 par défaut)
		FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
		final Path outDir = new Path(otherArgs[1]);
		FileOutputFormat.setOutputPath(job, outDir);
		final FileSystem fs = FileSystem.get(conf);//récupération d'une référence sur le système de fichier HDFS
		if (fs.exists(outDir)) {
			fs.delete(outDir, true);
		}
		//System.exit(job.waitForCompletion(true) ? 0 : 1);
		job.waitForCompletion(true);
	}

	public static List<Integer> getUniqueColors(int amount) {
		final int lowerLimit = 0x10;
		final int upperLimit = 0xE0;    
		final int colorStep = (int) ((upperLimit-lowerLimit)/Math.pow(amount,1f/3));

		final List<Integer> colors = new ArrayList<Integer>(amount);

		for (int R = lowerLimit;R < upperLimit; R+=colorStep)
			for (int G = lowerLimit;G < upperLimit; G+=colorStep)
				for (int B = lowerLimit;B < upperLimit; B+=colorStep) {
					if (colors.size() >= amount) { //The calculated step is not very precise, so this safeguard is appropriate
						return colors;
					} else {
						int color = (R<<16)+(G<<8)+(B);
						colors.add(color);
					}               
				}
		return colors;
	}

	public static int julia(double Ac , double Ab , double x , double y){
		Complex c = new Complex(Ac,Ab);
		Complex z = new Complex(x,y);
		for(int i = 0 ; i < 256 ; i++ ){
			Complex fz = (z.times(z)).plus(c);
			double norm = fz.abs();
			if(norm > 2.0){
				return i;
			}else{
				z = fz;
			}
		}
		return 10-1;
	}


	public static class TokenizerMapper 
	extends Mapper<Object, Text, Text, IntWritable>{

		private final static IntWritable res = new IntWritable(1);
		private Text word = new Text();


		public void map(Object key, Text value, Context context
				) throws IOException, InterruptedException {
			StringTokenizer itr = new StringTokenizer(value.toString());


			int i = Integer.parseInt(itr.nextToken());
			int j = Integer.parseInt(itr.nextToken());
			double x = xmin +  i * width / dim;
			double y = ymin + j * height / dim;
			int julia =  julia(real,imag,x,y);
			res.set(julia);
			word.set(i+" "+j);
			context.write(word, res);
			pic.set(i, j, new Color(colors.get(julia)));

		}
	}



	public static class IntSumReducer 
	extends Reducer<Text,IntWritable,Text,IntWritable> {
		private IntWritable result = new IntWritable();

		public void reduce(Text key, Iterable<IntWritable> values, 
				Context context
				) throws IOException, InterruptedException {


			if(test){
				pic.show();
				test = false;
			}
			int sum = 0;
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);

		}
	}


}
